﻿namespace WebAPICoreCS.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public string Gender { get; set; }
        public string Course { get; set; }
        public string DOB { get; set; }
    }
}
