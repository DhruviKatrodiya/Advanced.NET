﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using WebAPICoreCS.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebAPICoreCS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private static List<Course> courses = new List<Course>();

        public CourseController()
        {
            if(courses.Count <= 0)
            {
                courses.Add(new Course { CourseId = 1, CourseName = "M.SC.ICT" });
                courses.Add(new Course { CourseId = 2, CourseName = "M.SC.IT" });
            }
        }

        // GET: api/<CourseController>
        [HttpGet]
        public IEnumerable<Course> Get()
        {
            return courses.ToList();
        }

        // GET api/<CourseController>/5
        [HttpGet("{id}")]
        public Course Get(int id)
        {
            return courses.SingleOrDefault(c => c.CourseId == id);
        }

        // POST api/<CourseController>
        [HttpPost]
        public void Post([FromBody] Course newCourse)
        {
            Course courseToAdd = new Course();
            courseToAdd.CourseId = newCourse.CourseId;
            courseToAdd.CourseName = newCourse.CourseName;
            courses.Add(courseToAdd);
        }

        // PUT api/<CourseController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Course updatedCourse)
        {
            Course updateToCourse = Get(id);
            updateToCourse.CourseName = updatedCourse.CourseName;
        }

        // DELETE api/<CourseController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            courses.Remove(Get(id));
        }
    }
}
