﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using WebAPICoreCS.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebAPICoreCS.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private static List<Student> students = new List<Student>();
        public StudentController()
        {
            if(students.Count <= 0)
            {
                students.Add(new Student { StudentId=1,StudentName="Dhruvi",Gender="Female",Course="M.SC.(I.C.T)",DOB="22-01-2001"});
                students.Add(new Student { StudentId = 2, StudentName = "Shilpa", Gender = "Female", Course = "M.SC.(I.C.T)", DOB = "16-12-2000" });
            }
        }
        // GET: api/<StudentController>
        [HttpGet]
        public IEnumerable<Student> Get()
        {
            return students.ToList();
        }

        // GET api/<StudentController>/5
        [HttpGet("{id}")]
        public Student Get(int id)
        {
            return students.SingleOrDefault(s => s.StudentId == id);
        }

        // POST api/<StudentController>
        [HttpPost]
        public void Post([FromBody] Student newStudent)
        {
            Student studentToAdd = new Student();
            studentToAdd.StudentId = newStudent.StudentId;
            studentToAdd.StudentName = newStudent.StudentName;
            studentToAdd.Gender = newStudent.Gender;
            studentToAdd.DOB = newStudent.DOB;
            studentToAdd.Course = newStudent.Course;
            students.Add (studentToAdd);

        }

        // PUT api/<StudentController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Student updatedStudent)
        {
            Student studentToUpdate = Get(id);
            studentToUpdate.StudentName = updatedStudent.StudentName;
            studentToUpdate.Gender = updatedStudent.Gender;
            updatedStudent.DOB = updatedStudent.DOB;
            updatedStudent.Course = updatedStudent.Course;
        }

        // DELETE api/<StudentController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            students.Remove(Get(id));
        }
    }
}
