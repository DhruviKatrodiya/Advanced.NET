﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentDataEntityApp
{
    public partial class AddRoom : Form
    {
        StudentDBEntities studentDBEntities = new StudentDBEntities();
        public AddRoom()
        {
            InitializeComponent();
        }

        private void AddRoom_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = studentDBEntities.Rooms.Select(r => new 
            {r.RoomId , r.RoomType , r.RoomPrice , r.Student.StudentName}).ToList();
            comboStudentName.DataSource = studentDBEntities.Students.Select(s => new { s.StudentId,s.StudentName}).ToList();
            comboStudentName.DisplayMember = "StudentName";
            comboStudentName.ValueMember = "StudentId";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(comboStudentName.SelectedValue);
            Room room = new Room();
            room.RoomType = textRoomType.Text;
            room.RoomPrice = Convert.ToInt32(textRoomPrice.Text);
            room.StudentId = id;
            studentDBEntities.Rooms.Add(room);
            studentDBEntities.SaveChanges();
            AddRoom_Load(studentDBEntities, e);

        }

        private void btnGetRoomId_Click(object sender, EventArgs e)
        {
            int RoomId = Convert.ToInt32(textGetRoomId.Text);
            Room room = studentDBEntities.Rooms.Find(RoomId);
            textRoomType.Text = room.RoomType;
            textRoomPrice.Text = room.RoomPrice.ToString();
            comboStudentName.Text = room.Student.StudentName;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int RoomId = Convert.ToInt32(textGetRoomId.Text);
            Room room = new Room();
            Room r = studentDBEntities.Rooms.Find(RoomId);
            r.RoomType = textRoomType.Text;
            r.RoomPrice = Convert.ToInt32(textRoomPrice.Text);
            r.Student.StudentName = comboStudentName.Text;
            studentDBEntities.SaveChanges();
            AddRoom_Load(studentDBEntities, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int RoomId = Convert.ToInt32(textGetRoomId.Text);
            Room room = studentDBEntities.Rooms.Find(RoomId);
            studentDBEntities.Rooms.Remove(room);
            studentDBEntities.SaveChanges();
            AddRoom_Load(studentDBEntities, e);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = (from Room in studentDBEntities.Rooms
                                        where Room.RoomType.Contains(textRoomType.Text) ||
                                        Room.Student.StudentName.Contains(comboStudentName.Text)
                                        select new {Room.RoomId , Room.RoomType , Room.RoomPrice , Room.Student.StudentName})
                                        .ToList();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textRoomType.Clear();
            textRoomPrice.Clear();
            textGetRoomId.Clear();
            AddRoom_Load(studentDBEntities, e);
        }
    }
}
