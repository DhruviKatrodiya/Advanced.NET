﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentDataEntityApp
{
    public partial class AddStudent : Form
    {
       private StudentDBEntities studentDBEntities = new StudentDBEntities();
        public AddStudent()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnMoveRoom_Click(object sender, EventArgs e)
        {
            AddRoom room = new AddRoom();
            room.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = studentDBEntities.Students.Select(s => new {s.StudentId,s.StudentName,s.CourseName,s.Address}).ToList();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            student.StudentName = textStudentName.Text;
            student.CourseName = textCourseName.Text;
            student.Address = textAddress.Text;
            studentDBEntities.Students.Add(student);
            studentDBEntities.SaveChanges();
            Form1_Load(studentDBEntities, e);
        }

        private void getStudentId_Click(object sender, EventArgs e)
        {
            int studentId = Convert.ToInt32(textGetStudentId.Text);
            Student student = studentDBEntities.Students.Find(studentId);
            textStudentName.Text = student.StudentName;
            textCourseName.Text = student.CourseName;
            textAddress.Text = student.Address;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int studentId = Convert.ToInt32(textGetStudentId.Text);
            Student student = studentDBEntities.Students.Find(studentId);
            student.StudentName = textStudentName.Text;
            student.CourseName= textCourseName.Text;
            student.Address= textAddress.Text;
            studentDBEntities.SaveChanges();
            Form1_Load(studentDBEntities, e);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int studentId = Convert.ToInt32(textGetStudentId.Text);
            Student student = studentDBEntities.Students.Find(studentId);
            studentDBEntities.Students.Remove(student);
            studentDBEntities.SaveChanges();
            Form1_Load(studentDBEntities, e);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = (from Student in studentDBEntities.Students
                                        where Student.StudentName.Contains(textStudentName.Text) || 
                                        Student.CourseName.Contains(textCourseName.Text) || 
                                        Student.Address.Contains(textAddress.Text)
                                        select new {Student.StudentId , Student.StudentName , Student.CourseName , Student.Address})
                                        .ToList();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textStudentName.Clear();
            textCourseName.Clear();
            textAddress.Clear();
            textGetStudentId.Clear();
            Form1_Load(studentDBEntities, e);
        }
    }
}
