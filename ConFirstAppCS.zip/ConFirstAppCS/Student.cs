﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConFirstAppCS.Business

{
    class Student
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }

        public override string ToString()
        {
            return "Id : "+StudentId+"\nName : "+StudentName+"\nAge : "+Age+"\nGender : "+Gender;
        }
    }
    class StudentList
    {
        //public int studid;
        //public string name;
        //public void showData()
        //{
        //    Console.WriteLine(studid + name);
        //}

        private Student[] students = new Student[5];
        public Student newStudent
        {
            set
            {
                for (int i = 0; i < 5; i++)
                {
                    if (students[i] == null)
                    {
                        students[i] = value;
                        break;
                    }
                    else
                    {
                        if (i == 4)
                        {
                            Console.WriteLine("Overflow");
                        }
                    }
                }
            }
        }

        public Student this[string Index]
        {
            get
            {
                Student temp = null;
                foreach (Student s in students)
                {
                    if (s.StudentName.Equals(Index))
                    {
                        temp = s;
                        return temp;
                    }
                }
                
                return temp;
            }
        }
    }
}
