﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConFirstAppCS
{
    internal class Product
    {
        private int ProId;
        public int ProductId
        {
            get { return ProId; }
            set { ProId = value; }
        }
        public string ProductName { get; set; }
        private int Qty;
        public int Quantity
        {
            get { return Qty; }
        }
        public int Purchase
        {
            set { Qty = Qty + value; }
        }
        public int Sales
        {
            set 
            {
                if (value < Qty)
                {
                    Qty -= value;
                }
                else
                {
                    Console.WriteLine("Not able to sale producs due to less quantity");
                }
            }
        }
        public override string ToString()
        {
            return "Product : Id = "+ProId.ToString()+
                "Name = "+ProductName + 
                "Quantity = "+Qty.ToString();
        }
    }
}
