﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConFirstAppCS.Business
{
    class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Rate { get; set; }
        public override string ToString()
        {
            return "Id : "+ProductId+ "\nName : "+ProductName+"\nRate : "+Rate;
        }
    }
    class ProductList
    {
        private Product[] products = new Product[5];
        public Product newProduct
        {
            set
            {
                for(int i=0;i<5;i++)
                {
                    if(products[i]==null)
                    {
                        products[i] = value;
                        break;
                    }
                    else
                    {
                        if(i==4)
                        {
                            Console.WriteLine("Overflow");
                        }
                    }
                }
            }
        }
        public Product this[string Index]
        {
            get
            {
                Product temp = null;
                foreach(Product p in products)
                {
                    if(p.ProductName.Equals(Index))
                    {
                        temp = p;
                        return temp;
                    }
                }
                return temp;
            }
        }
    }
}
