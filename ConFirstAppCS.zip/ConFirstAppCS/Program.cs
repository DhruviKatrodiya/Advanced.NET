﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConFirstAppCS.Business;

namespace ConFirstAppCS
{
    internal class Program
    {
        static void Main1(string[] args)
        {
            /* Simple Display */

            //int x = 20;
            //if(x > 10)
            //{
            //    Console.WriteLine("> 10");
            //}
            //else
            //{
            //    Console.WriteLine("< 10");
            //}
            /* Display Student detail */

            //Student s = new Student();
            //s.studid = 1;
            //s.name = "Dhruvi";
            //s.showData();

            /* Display product sales and purchase */

            //Product p = new Product();
            //p.ProductId = 1;
            //p.ProductName = "Computer";
            //Console.WriteLine(p.ToString());
            //p.Purchase = 10;
            //Console.WriteLine(p.Quantity);
            //p.Sales = 16;
            //Console.WriteLine(p.Quantity);

            /* Simple addition substraction multiplication division 

            Console.Write("Enter a Number : ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter another Number : ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("{0} + {1} = {2}", num1, num2, num1 + num2);
            Console.WriteLine("{0} - {1} = {2}", num1, num2, num1 - num2);
            Console.WriteLine("{0} * {1} = {2}", num1, num2, num1 * num2);
            Console.WriteLine("{0} / {1} = {2}", num1, num2, num1 / num2);
            Console.WriteLine("{0} mod {1} = {2}", num1, num2, num1 % num2);*/

            /*int num1 = 0;
            int num2 = 0;

            Console.WriteLine("Console Calculator in C#\r");
            Console.WriteLine("------------------------\n");

            Console.WriteLine("Type a number , and then press Enter");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Type another number , and then press Enter");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Choose an option from the following list :");
            Console.WriteLine("\ta - Add");
            Console.WriteLine("\ts - Subtract");
            Console.WriteLine("\tm - Multiply");
            Console.WriteLine("\td - Divide");
            Console.Write("Your option?? ");

            switch(Console.ReadLine())
            {
                case "a":
                    Console.WriteLine($"Your result: {num1} + {num2} = " + (num1 + num2));
                    break;
                case "s":
                    Console.WriteLine($"Your result: {num1} - {num2} = " + (num1 - num2));
                    break;
                case "m":
                    Console.WriteLine($"Your result: {num1} * {num2} = " + (num1 * num2));
                    break;
                case "d":
                    Console.WriteLine($"Your result: {num1} / {num2} = " + (num1 / num2));
                    break;
            }
            Console.Write("Press any key to close the calculater console app...");*/

            /* user enter desire data in product */

            ProductList ProList = new ProductList();
            ProList.newProduct = new Business.Product()
            {
                ProductId = 1,
                ProductName = "Computer",
                Rate = 50000
            };

            ProList.newProduct = new Business.Product()
            {
                ProductId = 2,
                ProductName = "Laptop",
                Rate = 60000
            };

            ProList.newProduct = new Business.Product()
            {
                ProductId = 3,
                ProductName = "Chair",
                Rate = 5500
            };

            ProList.newProduct = new Business.Product()
            {
                ProductId = 4,
                ProductName = "Mobile",
                Rate = 100000
            };

            ProList.newProduct = new Business.Product()
            {
                ProductId = 5,
                ProductName = "Tv",
                Rate = 35000
            };

            Business.Product result = ProList["Chair"];
            if(result == null)
            {
                Console.WriteLine("No Data");
            }
            Console.WriteLine(result);

            Console.ReadKey();
        }
        static void Main(string[] args)
        {
            StudentList StudList = new StudentList();
            StudList.newStudent = new Business.Student()
            {
                StudentId = 1,
                StudentName = "Dhruvi",
                Age = 21,
                Gender = "Female"
            };

            StudList.newStudent = new Business.Student()
            {
                StudentId = 2,
                StudentName = "Shilpa",
                Age = 21,
                Gender = "Female"
            };

            StudList.newStudent = new Business.Student()
            {
                StudentId = 3,
                StudentName = "Krinal",
                Age = 23,
                Gender = "Female"
            };

            StudList.newStudent = new Business.Student()
            {
                StudentId = 4,
                StudentName = "Meet",
                Age = 19,
                Gender = "Male"
            };

            StudList.newStudent = new Business.Student()
            {
                StudentId = 5,
                StudentName = "Vidhi",
                Age = 20,
                Gender = "Female"
            };

            Business.Student result = StudList["Dhruvi"];
            if(result == null)
            {
                Console.WriteLine("No Data");
            }
            Console.WriteLine(result);

            
            Console.ReadKey();
        }
    }
}
