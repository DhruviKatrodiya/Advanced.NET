﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesInterfaceGeneric
{
    public class Program
    {
        public Circle GetShape()
        {
            double rad = 0.00D;

            Console.Write("Enter the radius: ");
            rad = double.Parse(Console.ReadLine());

            return new Circle(rad);
        }

        public void ShowShapes(IShapes<IRound> shps)
        {
            for (int i = 0; i < shps.Count; i++)
            {
                IRound rnd = shps.Get(i);

                Console.WriteLine("================================");
                Console.WriteLine("{0} Characteristics", rnd.Name);
                Console.WriteLine("--------------------------------");
                Console.WriteLine("Radius:        {0}", rnd.Radius);
                Console.WriteLine("Diameter:      {0}", rnd.Diameter);
                Console.WriteLine("Circumference: {0}", rnd.Circumference);
                Console.WriteLine("Area:          {0}", rnd.Area);
            }
            Console.WriteLine("===============================");
        }

        static void Main(string[] args)
        {
            Program exo = new Program();
            GeometricShapes<IRound> shapes = new GeometricShapes<IRound>();

            IRound rnd = exo.GetShape();
            shapes.Add(rnd);
            rnd = exo.GetShape();
            shapes.Add(rnd);
            rnd = exo.GetShape();
            shapes.Add(rnd);
            rnd = exo.GetShape();
            shapes.Add(rnd);
            rnd = exo.GetShape();
            shapes.Add(rnd);

            Console.Clear();
            exo.ShowShapes(shapes);

            Console.ReadKey();
        }
    }
}
