﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesInterfaceGeneric
{
    public interface IRound
    {
        string Name { get; }
        double Radius { get; set; }
        double Diameter { get; }
        double Circumference { get; }
        double Area { get; }
    }
}
