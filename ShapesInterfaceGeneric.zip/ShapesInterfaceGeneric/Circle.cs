﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesInterfaceGeneric
{
    public class Circle : IRound
    {
        protected double rad;
        protected string id;

        public Circle(double radius = 0.00D)
        {
            this.rad = radius;
        }

        public string Name { get { return "Circle"; } }

        public double Radius
        {
            get { return rad; }
            set
            {
                if (rad <= 0) rad = 0;
                else rad = value;
            }
        }

        public double Diameter { get { return rad * 2; } }

        public double Circumference { get { return rad * 2 * 3.14159; } }

        public double Area { get { return rad * rad * 3.14159; } }
    }
}
