﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesInterfaceGeneric
{
    public interface IShapes<T>
    {
        int Count { get; }
        void Add(T item);
        T Get(int index);
    }
}
