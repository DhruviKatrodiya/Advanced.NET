﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesInterfaceGeneric
{
    public class GeometricShapes<T> : IShapes<T>
    {
        private int size;
        private T[] items;

        public GeometricShapes()
        {
            size = 0;
            items = new T[10];
        }

        public int Count { get { return size; } }

        public void Add(T item)
        {
            this.items[this.size] = item;
            this.size++;
        }

        public T Get(int index) { return this.items[index]; }
    }
}
