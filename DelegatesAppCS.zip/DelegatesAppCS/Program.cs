﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesAppCS
{
    public delegate string DisplayDelegate();
    internal class Program
    {
        static void Main1(string[] args)
        {
            DelegateToMethod aDelegate = new DelegateToMethod(DelegatesClass.Add);
            DelegateToMethod mDelegate = new DelegateToMethod(DelegatesClass.Multiply);
            DelegateToMethod dDelegate = new DelegateToMethod(DelegatesClass.Divide);

            Console.WriteLine(aDelegate(5, 5));
            Console.WriteLine(mDelegate(5, 5));
            Console.WriteLine(dDelegate(5,5));
            Console.ReadKey();
        }

        static void Main2(string[] args)
        {
            Strudent s = new Strudent();
            s.StudentId = 1;
            s.StudentName = "Dhruvi";
            s.Programme = "M.SC.(I.C.T)";
            DisplayDelegate studDel = new DisplayDelegate(s.Display);
            Console.WriteLine(studDel());

            Programme p = new Programme();
            p.ProgrammeId = 1;
            p.ProgrammeName = "M.SC.(I.C.T)";
            DisplayDelegate proDel = new DisplayDelegate(p.Show);
            Console.WriteLine(proDel());

            Console.WriteLine("-------------------------");

            DisplayDelegate comDelegate = proDel + studDel;
            Console.WriteLine(comDelegate());

            Console.WriteLine("-------------------------");

            comDelegate -= studDel;
            Console.WriteLine(comDelegate());

            Console.ReadKey();
        }

        static void Main3(string[] args)
        {
            Strudent s = new Strudent();
            s.StudentId = 1;
            s.StudentName = "Dhruvi";
            s.Programme = "M.SC.(I.C.T)";
            //DisplayDelegate studDel = new DisplayDelegate(s.Display);
            //Console.WriteLine(studDel());

            Programme p = new Programme();
            p.ProgrammeId = 1;
            p.ProgrammeName = "M.SC.(I.C.T)";
            DisplayDelegate comDel = new DisplayDelegate(p.Show);
            comDel += new DisplayDelegate(s.Display);
            Console.WriteLine(comDel());



            Console.ReadKey();
        }

        static void Main(string[] args)
        {
            DelegateManager dm = new DelegateManager();
            
            Strudent s = new Strudent();
            s.StudentId = 1;
            s.StudentName = "Dhruvi";
            s.Programme = "M.SC.(I.C.T)";

            Programme p = new Programme();
            p.ProgrammeId = 1;
            p.ProgrammeName = "M.SC.(I.C.T)";

            dm.delegateRef += new DisplayDelegate(s.Display);
            dm.delegateRef += new DisplayDelegate(p.Show);

            dm.getDataUsingDelegate();

            Console.ReadKey();
        }
    }
}
