﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesAppCS
{
    internal class Strudent
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public string Programme { get; set; }
        public string Display()
        {
            Console.WriteLine("Display - Student");
            return "This is from display method of student class \n"
                +StudentId+"\n"+StudentName+"\n"+Programme+"\n\n";
        }
    }
}
