﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesAppCS
{
    public delegate int DelegateToMethod(int x, int y);
    internal class DelegatesClass
    {
        public static int Add(int first,int second)
        {
            return first + second;
        }
        public static int Multiply(int first,int second)
        {
            return first * second;
        }

        public static int Divide(int first,int second)
        {
            return first / second;
        }
    }
}
