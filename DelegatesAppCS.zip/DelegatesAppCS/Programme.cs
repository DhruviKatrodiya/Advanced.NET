﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesAppCS
{
    internal class Programme
    {
        public int ProgrammeId { get; set; }
        public string ProgrammeName { get; set; }
        public string Show()
        {
            Console.WriteLine("Show - Programme");
            return "This is from show method of programme class \n"
                +ProgrammeId+"\n"+ProgrammeName+"\n";
        }
    }
}
