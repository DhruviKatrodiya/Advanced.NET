﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesAppCS
{
    internal class DelegateManager
    {
        public DisplayDelegate delegateRef { get; set; }

        public void getDataUsingDelegate()
        {
            if(delegateRef == null)
            {
                Console.WriteLine("No Method to call ");
            }
            else
            {
                Console.WriteLine(delegateRef());
            }
        }
    }
}
